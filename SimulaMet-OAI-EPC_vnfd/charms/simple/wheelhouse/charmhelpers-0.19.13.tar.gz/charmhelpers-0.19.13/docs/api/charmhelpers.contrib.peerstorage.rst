charmhelpers.contrib.peerstorage package
========================================

.. automodule:: charmhelpers.contrib.peerstorage
    :members:
    :undoc-members:
    :show-inheritance:
