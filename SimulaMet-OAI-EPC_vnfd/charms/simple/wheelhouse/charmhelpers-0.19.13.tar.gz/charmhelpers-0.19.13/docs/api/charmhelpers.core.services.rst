charmhelpers.core.services
==========================

.. toctree::

    charmhelpers.core.services.base
    charmhelpers.core.services.helpers

.. automodule:: charmhelpers.core.services
    :members:
    :undoc-members:
    :show-inheritance:
